const CATALOG = [
    {
        id: 'el3',
        name: '  Джинсовая куртка Dracon',
        img: 'товар.дев.jpg',
        price: 17.99,
        
    },
    {
        id: 'el4',
        name: 'Рубашка с принтом',
        img: 'товар.дев2.jpg',
        price: 19.99,
    },
    
];