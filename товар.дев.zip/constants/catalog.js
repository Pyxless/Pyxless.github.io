const CATALOG = [
    {
        id: 'el1',
        name: '  Джинсовая куртка xxxtentacion',
        img: 'товар2.jpg',
        price: 17.99,
    },
    {
        id: 'el2',
        name: 'Мужская толстовка 3D с принтом Hajime',
        img: 'товар.jfif',
        price: 19.99,
    },
    
];